/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useState, useEffect } from 'react';
import { AppView, Order } from './types';
import { businessDetails } from './data';
import LoginScreen from './components/LoginScreen';
import POSView from './components/POSView';

// A simple component for displaying order history
function OrderHistory({ orders, onBack }: { orders: Order[], onBack: () => void }) {
    return (
        <div className="bg-slate-800 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">Order History</h2>
                <button onClick={onBack} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">Back to POS</button>
            </div>
            <div className="space-y-2">
                {orders.length === 0 ? <p>No orders yet.</p> : orders.map(order => (
                    <div key={order.id} className="bg-slate-700 p-3 rounded">
                        <div className="flex justify-between">
                            <span>Bill #{order.billNo}</span>
                            <span>{new Date(order.date).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between font-bold text-lg">
                            <span>Total: ₹{order.total.toFixed(2)}</span>
                            <span>Cashier: {order.cashier}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('LOGIN');
  const [orders, setOrders] = useState<Order[]>([]);
  const [user, setUser] = useState<'Staff' | 'Admin' | null>(null);

  // A mock function to add orders, in a real app this would be part of the POSView logic
  // and passed down. For now, we'll add it here to demonstrate history.
  const addOrder = (order: Order) => {
      setOrders(prev => [order, ...prev]);
  }

  const handleLogin = (loggedInUser: 'Staff' | 'Admin') => {
    setUser(loggedInUser);
    setCurrentView('POS');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('LOGIN');
  };

  const renderView = () => {
    switch (currentView) {
      case 'LOGIN':
        return <LoginScreen onLogin={handleLogin} />;
      case 'POS':
        return user ? <POSView user={user} onLogout={handleLogout} onViewHistory={() => setCurrentView('HISTORY')} onAddOrder={addOrder} /> : <LoginScreen onLogin={handleLogin} />;
      case 'HISTORY':
        return <OrderHistory orders={orders} onBack={() => setCurrentView('POS')} />;
      default:
        return <LoginScreen onLogin={handleLogin} />;
    }
  }

  return (
    <div className="h-screen w-screen bg-slate-900 text-slate-100 font-sans">
      <div className="container mx-auto p-4">
        <header className="text-center mb-4">
            <h1 className="text-3xl font-bold">{businessDetails.name}</h1>
            <p className="text-slate-400">POS System</p>
        </header>
        <main>
            {renderView()}
        </main>
      </div>
    </div>
  );
}
