import { Menu } from './types';

export const menuData: Menu = {
  "Signature Rolls": {
    name: "Signature Rolls",
    items: [
      { name: "Beef Seekh Roll", price: { Regular: 100, Jumbo: 130, Mambo: 180 } },
      { name: "Beef Phall Roll", price: { Regular: 100, Jumbo: 130, Mambo: 180 } },
      { name: "Beef Shahi Kebab Roll", price: { Regular: 130, Jumbo: 180 } },
      { name: "Beef Hyderabadi Roll", price: { Regular: 130, Jumbo: 180 } },
      { name: "Beef Shahi Phall Roll", price: { Regular: 130, Jumbo: 180 } },
      { name: "Beef Veal Roll", price: { Regular: 130, Jumbo: 180 } },
      { name: "Beef Arabian Roll", price: { Jumbo: 180 } },
    ],
  },
  "Beef Specialties": {
    name: "Beef Specialties",
    items: [
      { name: "Beef Seekh Kebab", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Shahi Kebab", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Masala Kebab", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Hyderabadi Kebab", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Shahi Phall", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Manchurian", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Chinese Chilli Kebab", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Veal Kebab", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Grilled Chops (Phall)", price: { Regular: 80, "Large (Value Pack)": 100 } },
      { name: "Beef Kadi ki Phall", price: { "Large (Value Pack)": 100 } },
      { name: "Beef Patthar Phall", price: { "Large (Value Pack)": 130 } },
    ],
  },
  "Chicken & Specialized Poultry": {
    name: "Chicken & Specialized Poultry",
    items: [
      { name: "Chicken Kebab", price: { "4 pcs": 80, "8 pcs": 160, "16 pcs": 320 } },
      { name: "Chicken Kalmi (Leg)", price: { "1 pc": 60, "2 pcs": 100 } },
      { name: "Chicken Wings", price: { "4 pcs": 100, "8 pcs": 200 } },
      { name: "Chicken Tikka", price: { "4 pcs": 100, "8 pcs": 200 } },
      { name: "Chicken Malai Tikka", price: { "4 pcs": 100, "8 pcs": 200 } },
      { name: "Chicken Hariyali Tikka", price: { "4 pcs": 100, "8 pcs": 200 } },
      { name: "Tangdi Kebab (Red/Green)", price: 150 },
      { name: "Chicken Alfaham", price: { Half: 200, Full: 350 } },
      { name: "Teetar (Quail)", price: 160 },
    ],
  },
  "Rice & Sides": {
    name: "Rice & Sides",
    items: [
      { name: "Chicken Biryani", price: 100 },
      { name: "Beef Biryani", price: 100 },
      { name: "Chicken / Beef Khushka", price: 70 },
      { name: "Rumali Roti", price: 20 },
      { name: "Sevi (Dessert)", price: 20 },
    ],
  },
  "Soups & Drinks": {
    name: "Soups & Drinks",
    items: [
      { name: "Bone Marrow (Nalli) Soup", price: { Regular: 80, Large: 100 } },
      { name: "Plain Soup", price: 50 },
      { name: "Cool Drinks", price: 20 },
      { name: "Water Bottle", price: 10 },
    ],
  },
  "Special Combo Meals": {
    name: "Special Combo Meals",
    items: [
        { name: "Student Combo", price: 100 },
        { name: "The Biryani Deal", price: 100 },
        { name: "The Quick Roll", price: 100 },
        { name: "Kebab & Roti Feast", price: 150 },
        { name: "Chicken Tikka Meal", price: 150 },
        { name: "Soup & Starter", price: 150 },
    ]
  },
  "Premium Platters": {
    name: "Premium Platters",
    items: [
        { name: "The Jumbo Roll Combo", price: 200 },
        { name: "Leg Kebab Platter", price: 200 },
        { name: "Mix Beef Platter", price: 200 },
        { name: "The Family Mix", price: 500 },
        { name: "The Full Alfaham Feast", price: 500 },
    ]
  }
};

export const businessDetails = {
    name: "COLES PARK STANDARD KABAB CENTER",
    branch: "H.B.S",
    address: "Haines Road, Bangalore-5600005.",
    phone: "963276874",
    logoUrl: "/logo.png", // Placeholder
    qrCodeUrl: "/qr-code.png" // Placeholder
};
