export interface MenuItem {
  name: string;
  price: number | { [key: string]: number };
  options?: string[];
  qty?: { [key: string]: number | string };
}

export interface Category {
  name: string;
  items: MenuItem[];
}

export interface Menu {
  [key: string]: Category;
}

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  option?: string;
}

export type PaymentMethod = 'Cash' | 'Online' | 'Split';

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  date: string;
  billNo: number;
  cashier: 'Staff' | 'Admin';
  paymentMethod: PaymentMethod;
}

export type AppView = 'LOGIN' | 'POS' | 'DASHBOARD' | 'HISTORY' | 'ADMIN';
