import { useState } from 'react';
import { menuData } from '../data';
import { CartItem, MenuItem } from '../types';
import MenuCategory from './MenuCategory';
import Cart from './Cart';
import { printerService } from '../components/PrinterService';

import { Order } from '../types';

interface POSViewProps {
  user: 'Staff' | 'Admin';
  onLogout: () => void;
  onViewHistory: () => void;
  onAddOrder: (order: Order) => void;
}

export default function POSView({ user, onLogout, onViewHistory, onAddOrder }: POSViewProps) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCategory, setActiveCategory] = useState(Object.keys(menuData)[0]);
  const [isPrinterConnected, setIsPrinterConnected] = useState(printerService.isConnected());

  const handleConnectPrinter = async () => {
    try {
      await printerService.connect();
      setIsPrinterConnected(true);
      alert('Printer connected successfully!');
    } catch (error: any) {
      if (error.message !== 'cancelled') {
        alert('Failed to connect to printer.');
      }
    }
  };

  const addToCart = (item: MenuItem, option?: string) => {
    const price = typeof item.price === 'number' ? item.price : item.price[option!];
    const cartId = `${item.name}${option ? ` (${option})` : ''}`;

    setCart((prevCart) => {
      const existingItem = prevCart.find((ci) => ci.id === cartId);
      if (existingItem) {
        return prevCart.map((ci) =>
          ci.id === cartId ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      } else {
        return [...prevCart, { id: cartId, name: item.name, price, quantity: 1, option }];
      }
    });
  };

  const updateCartQuantity = (itemId: string, newQuantity: number) => {
    setCart((prevCart) => {
      if (newQuantity <= 0) {
        return prevCart.filter((item) => item.id !== itemId);
      }
      return prevCart.map((item) =>
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      );
    });
  };

  const clearCart = () => {
    setCart([]);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[calc(100vh-100px)]">
      <div className="lg:col-span-2 bg-slate-800 p-4 rounded-lg overflow-y-auto">
        <div className="flex flex-wrap gap-2 mb-4">
          {Object.keys(menuData).map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-semibold ${activeCategory === category ? 'bg-blue-500 text-white' : 'bg-slate-700 text-slate-300'}`}>
              {category}
            </button>
          ))}
        </div>
        <MenuCategory category={menuData[activeCategory]} onAddToCart={addToCart} />
      </div>
      <div className="bg-slate-800 p-4 rounded-lg">
        <Cart cart={cart} onUpdateQuantity={updateCartQuantity} onClearCart={clearCart} user={user} onAddOrder={onAddOrder} />
        <div className="mt-4 flex flex-col gap-2">
            <button onClick={handleConnectPrinter} className={`font-bold py-2 px-4 rounded w-full ${isPrinterConnected ? 'bg-green-500' : 'bg-gray-500 hover:bg-gray-600'}`}>
                {isPrinterConnected ? 'Printer Connected' : 'Connect to Printer'}
            </button>
            <button onClick={onViewHistory} className="bg-purple-500 hover:bg-purple-600 text-white font-bold py-2 px-4 rounded w-full">Order History</button>
            <button onClick={onLogout} className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded w-full">Logout</button>
        </div>
      </div>
    </div>
  );
}
