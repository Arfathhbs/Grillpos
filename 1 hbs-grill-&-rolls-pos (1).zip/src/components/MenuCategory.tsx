import { Category, MenuItem } from '../types';

interface MenuCategoryProps {
  category: Category;
  onAddToCart: (item: MenuItem, option?: string) => void;
}

export default function MenuCategory({ category, onAddToCart }: MenuCategoryProps) {
  return (
    <div>
      <h3 className="text-xl font-bold mb-2">{category.name}</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {category.items.map((item) => (
          <div key={item.name} className="bg-slate-700 p-3 rounded-lg flex flex-col">
            <h4 className="font-semibold text-base mb-1 flex-grow">{item.name}</h4>
            {typeof item.price === 'number' ? (
              <button onClick={() => onAddToCart(item)} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-2 rounded mt-2">
                ₹{item.price}
              </button>
            ) : (
              <div className="flex flex-col gap-2 mt-2">
                {Object.entries(item.price).map(([option, price]) => (
                  <button key={option} onClick={() => onAddToCart(item, option)} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-2 rounded text-sm">
                    {option}: ₹{price}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
