import { useState } from 'react';

interface LoginScreenProps {
  onLogin: (user: 'Staff' | 'Admin', pin?: string) => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [pin, setPin] = useState('');

  const handleAdminLogin = () => {
    // For simplicity, using a hardcoded PIN. In a real app, this would be validated on a server.
    if (pin === '1234') {
      onLogin('Admin', pin);
    } else {
      alert('Invalid PIN');
      setPin('');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full">
      <h2 className="text-2xl mb-4">Login</h2>
      <div className="flex gap-4 mb-4">
        <button onClick={() => onLogin('Staff')} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
          Staff Login
        </button>
      </div>
      <div className="flex flex-col items-center gap-2">
        <input
          type="password"
          value={pin}
          onChange={(e) => setPin(e.target.value)}
          placeholder="Admin PIN"
          className="bg-slate-800 text-white p-2 rounded w-48 text-center"
        />
        <button onClick={handleAdminLogin} className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">
          Admin Login
        </button>
      </div>
    </div>
  );
}
