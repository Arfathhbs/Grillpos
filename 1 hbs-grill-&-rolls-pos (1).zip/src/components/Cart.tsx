import { useState } from 'react';
import { CartItem, Order, PaymentMethod } from '../types';
import ReceiptModal from './ReceiptModal';
import { businessDetails } from '../data';

interface CartProps {
  cart: CartItem[];
  onUpdateQuantity: (itemId: string, newQuantity: number) => void;
  onClearCart: () => void;
  user: 'Staff' | 'Admin';
  onAddOrder: (order: Order) => void;
}

let orderCounter = 1;

export default function Cart({ cart, onUpdateQuantity, onClearCart, user, onAddOrder }: CartProps) {
  const [showReceipt, setShowReceipt] = useState(false);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleProcessPayment = (method: PaymentMethod) => {
    const newOrder: Order = {
        id: new Date().toISOString(),
        items: cart,
        total: total,
        date: new Date().toISOString(),
        billNo: orderCounter++,
        cashier: user,
        paymentMethod: method
    };
    setLastOrder(newOrder);
    onAddOrder(newOrder);
    setShowReceipt(true);
    onClearCart();
  };

  return (
    <div className="flex flex-col h-full">
      <h3 className="text-xl font-bold mb-2">Current Order</h3>
      <div className="flex-grow overflow-y-auto pr-2">
        {cart.length === 0 ? (
          <p className="text-slate-400">Cart is empty</p>
        ) : (
          cart.map((item) => (
            <div key={item.id} className="flex justify-between items-center mb-2 bg-slate-700 p-2 rounded">
              <div>
                <p className="font-semibold">{item.name}</p>
                {item.option && <p className="text-sm text-slate-400">{item.option}</p>}
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} className="w-6 h-6 bg-slate-600 rounded-full">-</button>
                <span>{item.quantity}</span>
                <button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} className="w-6 h-6 bg-slate-600 rounded-full">+</button>
                <span className="w-16 text-right">₹{(item.price * item.quantity).toFixed(2)}</span>
              </div>
            </div>
          ))
        )}
      </div>
      <div className="mt-auto pt-4 border-t border-slate-700">
        <div className="flex justify-between font-bold text-lg mb-4">
          <span>Total:</span>
          <span>₹{total.toFixed(2)}</span>
        </div>
        <div className="grid grid-cols-3 gap-2 mb-2">
            <button onClick={() => handleProcessPayment('Cash')} disabled={cart.length === 0} className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded disabled:bg-slate-600">Cash</button>
            <button onClick={() => handleProcessPayment('Online')} disabled={cart.length === 0} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded disabled:bg-slate-600">Online</button>
            <button onClick={() => handleProcessPayment('Split')} disabled={cart.length === 0} className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded disabled:bg-slate-600">Split</button>
        </div>
        <button onClick={onClearCart} disabled={cart.length === 0} className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded disabled:bg-slate-600 w-full">
            Clear Cart
        </button>
      </div>
      {showReceipt && lastOrder && (
        <ReceiptModal order={lastOrder} businessDetails={businessDetails} onClose={() => setShowReceipt(false)} />
      )}
    </div>
  );
}
