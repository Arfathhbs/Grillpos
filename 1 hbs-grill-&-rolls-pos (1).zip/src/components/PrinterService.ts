// A placeholder for the Bluetooth thermal printer service

class PrinterService {
    private device: BluetoothDevice | null = null;
    private server: BluetoothRemoteGATTServer | null = null;
    private characteristic: BluetoothRemoteGATTCharacteristic | null = null;

    async connect(): Promise<void> {
        try {
            this.device = await navigator.bluetooth.requestDevice({
                filters: [{ services: ['000018f0-0000-1000-8000-00805f9b34fb'] }], // Generic Attribute Profile
            });

            if (!this.device.gatt) {
                throw new Error('GATT server not available');
            }

            this.server = await this.device.gatt.connect();
            const service = await this.server.getPrimaryService('000018f0-0000-1000-8000-00805f9b34fb');
            this.characteristic = await service.getCharacteristic('00002af1-0000-1000-8000-00805f9b34fb');
            
            console.log('Connected to printer');

        } catch (error: any) {
            if (error.name === 'NotFoundError' || (error.message && error.message.includes('User cancelled'))) {
                console.log('User cancelled Bluetooth device selection.');
                throw new Error('cancelled');
            }
            console.error('Failed to connect to printer:', error);
            throw error;
        }
    }

    async print(receiptData: string): Promise<void> {
        if (!this.characteristic) {
            throw new Error('Not connected to a printer');
        }

        const encoder = new TextEncoder();
        const data = encoder.encode(receiptData);
        const chunkSize = 64; // Max size of a chunk to send

        try {
            for (let i = 0; i < data.length; i += chunkSize) {
                const chunk = data.slice(i, i + chunkSize);
                await this.characteristic.writeValue(chunk);
                // Add a small delay between chunks to allow the printer to process
                await new Promise(resolve => setTimeout(resolve, 50));
            }
            console.log('Printed successfully');
        } catch (error) {
            console.error('Failed to print:', error);
            throw error;
        }
    }

    isConnected(): boolean {
        return !!this.device && !!this.server && this.server.connected;
    }
}

export const printerService = new PrinterService();
