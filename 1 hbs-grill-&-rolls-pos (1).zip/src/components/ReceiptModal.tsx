import { Order } from '../types';
import { businessDetails } from '../data';
import { printerService } from './PrinterService';

interface ReceiptModalProps {
  order: Order;
  businessDetails: typeof businessDetails;
  onClose: () => void;
}

export default function ReceiptModal({ order, businessDetails, onClose }: ReceiptModalProps) {
    const handlePrint = async () => {
    if (printerService.isConnected()) {
        // Format data for thermal printer (simple text format)
        const receiptText = `
${businessDetails.name}
${businessDetails.branch}
${businessDetails.address}
Ph: ${businessDetails.phone}
--------------------------------
Date: ${new Date(order.date).toLocaleDateString()} ${new Date(order.date).toLocaleTimeString()}
Bill No: ${order.billNo} Cashier: ${order.cashier}
Payment: ${order.paymentMethod}
--------------------------------
Item         Qty    Price
--------------------------------
${order.items.map(item => `${item.name.padEnd(12).substring(0,12)} ${item.quantity.toString().padStart(3)}  ${(item.price * item.quantity).toFixed(2).padStart(7)}`).join('\n')}
--------------------------------
Total:              ${order.total.toFixed(2).padStart(7)}

Scan QR to Pay via UPI

Thank you for your business!
Please visit again!


`;
        try {
            await printerService.print(receiptText);
        } catch (error) {
            alert('Printing failed. Please try again.');
        }
    } else {
        // Fallback to browser print if not connected
        window.print();
    }
};

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white text-black p-6 rounded-lg max-w-sm w-full relative">
        <div id="receipt-print">
            <div className="text-center mb-4">
                {/* In a real app, you'd use an <img> tag with the logo URL */}
                <h2 className="text-xl font-bold">{businessDetails.name}</h2>
                <p>{businessDetails.branch}</p>
                <p>{businessDetails.address}</p>
                <p>Ph: {businessDetails.phone}</p>
            </div>
            <div className="flex justify-between border-t border-b border-dashed border-black py-1">
                <span>Date: {new Date(order.date).toLocaleDateString()}</span>
                <span>Time: {new Date(order.date).toLocaleTimeString()}</span>
            </div>
            <div className="flex justify-between py-1">
                <span>Bill No: {order.billNo}</span>
                <span>Cashier: {order.cashier}</span>
                <span>Payment: {order.paymentMethod}</span>
            </div>
            <div className="border-t border-dashed border-black pt-2 mt-1">
                <div className="grid grid-cols-4 font-bold">
                    <span className="col-span-2">Item</span>
                    <span>Qty</span>
                    <span className="text-right">Price</span>
                </div>
                {order.items.map(item => (
                    <div key={item.id} className="grid grid-cols-4">
                        <span className="col-span-2">{item.name}{item.option ? ` (${item.option})` : ''}</span>
                        <span>{item.quantity}</span>
                        <span className="text-right">₹{(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                ))}
            </div>
            <div className="border-t border-dashed border-black mt-2 pt-2">
                <div className="flex justify-between font-bold text-lg">
                    <span>Total:</span>
                    <span>₹{order.total.toFixed(2)}</span>
                </div>
            </div>
            <div className="text-center mt-4">
                {/* In a real app, you'd use an <img> tag with the QR code URL */}
                <p>Scan QR to Pay via UPI</p>
                <p className="font-bold mt-2">Thank you for your business!</p>
                <p>Please visit again!</p>
            </div>
        </div>
        <div className="flex justify-between mt-6">
            <button onClick={onClose} className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded">Close</button>
            <button onClick={handlePrint} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">Print</button>
        </div>
      </div>
    </div>
  );
}
